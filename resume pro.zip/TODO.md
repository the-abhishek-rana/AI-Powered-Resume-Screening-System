# TODO: Fix CORS Issue for Chatbot Endpoint

## Steps to Complete:
- [x] Update CORS configuration in backend/app.py to explicitly allow frontend origin with credentials, headers, and methods
- [ ] Restart the backend Flask server (run: cd backend && python app.py)
- [ ] Test the frontend fetch to /chatbot endpoint
