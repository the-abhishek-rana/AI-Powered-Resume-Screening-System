import React, { useState } from 'react';
import { Upload, TrendingUp, AlertCircle, CheckCircle2, XCircle, Lightbulb, FileText } from 'lucide-react';
import { extractTextFromPDF } from '../lib/pdfUtils';
import { groq } from '../lib/groqClient';

interface AnalysisResult {
  matchScore: number;
  matchedSkills: string[];
  missingSkills: string[];
  improvementSuggestions: string;
  keywordAnalysis: {
    totalKeywords: number;
    matchedKeywords: number;
  };
}

export const ResumeRanking: React.FC = () => {
  console.log('ResumeRanking component rendered');
  const [file, setFile] = useState<File | null>(null);
  const [companyName, setCompanyName] = useState('');
  const [jobRole, setJobRole] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState('');

  const hasResumeKeywords = (text: string): boolean => {
    const keywords = ['experience', 'education', 'skills', 'work', 'employment', 'qualification', 'resume', 'cv', 'curriculum vitae'];
    const lowerText = text.toLowerCase();
    return keywords.some(keyword => lowerText.includes(keyword));
  };

  const parseJsonSafely = (text: string) => {
    // Remove markdown code blocks if present
    let cleanedText = text.replace(/```json\s*/g, '').replace(/```\s*$/g, '').trim();

    try {
      return JSON.parse(cleanedText);
    } catch (e) {
      // Try to extract JSON from the text
      const jsonMatch = cleanedText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          return JSON.parse(jsonMatch[0]);
        } catch (e2) {
          throw new Error('Invalid JSON response from AI: ' + cleanedText.substring(0, 100) + '...');
        }
      }
      throw new Error('No JSON found in response: ' + cleanedText.substring(0, 100) + '...');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      if (selectedFile.type === 'application/pdf' || selectedFile.name.endsWith('.pdf')) {
        setFile(selectedFile);
        setError('');
      } else {
        setError('Please upload a PDF file');
        setFile(null);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!file) {
      setError('Please upload a resume file');
      return;
    }

    setAnalyzing(true);
    setError('');

    try {
      const resumeText = await extractTextFromPDF(file);

      // Basic keyword check
      if (!hasResumeKeywords(resumeText)) {
        setError('The uploaded document does not appear to be a resume. Please upload a valid resume PDF.');
        setAnalyzing(false);
        return;
      }

      // Classify document type
      const classificationPrompt = `Analyze the following document text. Determine if this is a resume/CV by checking for presence of:
- Personal information (name, contact details)
- Professional experience/work history
- Education background
- Skills or qualifications
- Objective or summary section

Respond with only 'resume' if it appears to be a resume/CV, otherwise respond with 'not resume'.

Document text: ${resumeText}`;

      const classificationResponse = await groq.chat.completions.create({
        messages: [{ role: 'user', content: classificationPrompt }],
        model: 'llama-3.1-8b-instant',
        temperature: 0,
      });

      const docType = classificationResponse.choices[0]?.message?.content?.trim().toLowerCase();

      if (docType !== 'resume') {
        setError('The uploaded document does not appear to be a resume. Please upload a valid resume PDF.');
        setAnalyzing(false);
        return;
      }

      // Validate company name and job role
      const validationPrompt = `Validate the following inputs for resume analysis:

Company Name: "${companyName}"
Job Role: "${jobRole}"

Please check:
1. Is the company name a real, known company or organization?
2. Is the job role a valid, standard job title?

Respond ONLY with a valid JSON object in this exact format:
{
  "companyValid": true/false,
  "jobValid": true/false,
  "companySuggestion": "suggested company name" or null,
  "jobSuggestion": "suggested job title" or null
}

If the inputs are valid, set both to true and suggestions to null. If invalid, provide suggestions if possible.`;

      const validationResponse = await groq.chat.completions.create({
        messages: [{ role: 'user', content: validationPrompt }],
        model: 'llama-3.1-8b-instant',
        temperature: 0,
      });

      if (!validationResponse.choices[0]?.message?.content) {
        setError('Failed to validate inputs');
        setAnalyzing(false);
        return;
      }

      const validation = parseJsonSafely(validationResponse.choices[0].message.content);

      if (!validation.companyValid || !validation.jobValid) {
        let errorMsg = 'Invalid inputs:';
        if (!validation.companyValid) {
          errorMsg += ` Company name "${companyName}" is not recognized.`;
          if (validation.companySuggestion) {
            errorMsg += ` Suggested: ${validation.companySuggestion}`;
          }
        }
        if (!validation.jobValid) {
          errorMsg += ` Job role "${jobRole}" is not a standard title.`;
          if (validation.jobSuggestion) {
            errorMsg += ` Suggested: ${validation.jobSuggestion}`;
          }
        }
        setError(errorMsg);
        setAnalyzing(false);
        return;
      }

      const prompt = `
        Analyze this resume for the job role "${jobRole}" at "${companyName}".
        ${jobDescription ? `Job description: ${jobDescription}` : ''}
        Resume text: ${resumeText}

        Respond ONLY with a valid JSON object in the following exact structure. Do not include any explanations, markdown, or additional text:

        {
          "matchScore": number (0-100),
          "matchedSkills": array of strings,
          "missingSkills": array of strings,
          "improvementSuggestions": string,
          "keywordAnalysis": {
            "totalKeywords": number,
            "matchedKeywords": number
          }
        }
      `;

      const response = await groq.chat.completions.create({
        messages: [{ role: 'user', content: prompt }],
        model: 'llama-3.1-8b-instant',
        temperature: 0,
      });

      if (!response.choices[0]?.message?.content) {
        setError('Failed to get analysis from Groq API');
        setAnalyzing(false);
        return;
      }

      const analysisData = parseJsonSafely(response.choices[0].message.content);
      setAnalysisResult(analysisData);
    } catch (err) {
      setError('Error analyzing resume: ' + (err as Error).message);
    } finally {
      setAnalyzing(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-orange-600';
    return 'text-red-600';
  };

  const getScoreBackground = (score: number) => {
    if (score >= 80) return 'bg-green-100';
    if (score >= 60) return 'bg-orange-100';
    return 'bg-red-100';
  };

  return (
    <div className="p-4 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 lg:p-8 mb-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Resume Analysis</h2>
            <p className="text-gray-600">Upload your resume and provide job details to get AI-powered insights</p>
          </div>

          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-start">
              <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
              <span className="text-sm">{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-3">Upload Resume</label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
                <input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileChange}
                  className="hidden"
                  id="resume-upload"
                />
                <label htmlFor="resume-upload" className="cursor-pointer">
                  {file ? (
                    <div className="flex flex-col items-center">
                      <FileText className="h-12 w-12 text-green-600 mb-3" />
                      <p className="text-sm font-medium text-gray-900">{file.name}</p>
                      <p className="text-xs text-gray-500 mt-1">Click to change file</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center">
                      <Upload className="h-12 w-12 text-gray-400 mb-3" />
                      <p className="text-sm font-medium text-gray-900">Click to upload resume</p>
                      <p className="text-xs text-gray-500 mt-1">PDF format only</p>
                    </div>
                  )}
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Company Name</label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Google, Microsoft, Amazon"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Job Role</label>
                <input
                  type="text"
                  value={jobRole}
                  onChange={(e) => setJobRole(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Senior Software Engineer"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Job Description
                <span className="text-gray-500 font-normal ml-2">(Optional)</span>
              </label>
              <textarea
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Paste the job description here for more accurate analysis..."
              />
            </div>

            <button
              type="submit"
              disabled={analyzing}
              className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg font-semibold hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 flex items-center justify-center space-x-2"
            >
              {analyzing ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Analyzing Resume...</span>
                </>
              ) : (
                <>
                  <TrendingUp className="h-5 w-5" />
                  <span>Analyze Resume</span>
                </>
              )}
            </button>
          </form>
        </div>

        {analysisResult && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 lg:p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Match Score</h3>
                <div className={`${getScoreBackground(analysisResult.matchScore)} px-6 py-3 rounded-lg`}>
                  <span className={`text-3xl font-bold ${getScoreColor(analysisResult.matchScore)}`}>
                    {analysisResult.matchScore}%
                  </span>
                </div>
              </div>

              <div className="w-full bg-gray-200 rounded-full h-4 mb-4">
                <div
                  className={`h-4 rounded-full transition-all duration-1000 ${
                    analysisResult.matchScore >= 80
                      ? 'bg-green-600'
                      : analysisResult.matchScore >= 60
                      ? 'bg-orange-600'
                      : 'bg-red-600'
                  }`}
                  style={{ width: `${analysisResult.matchScore}%` }}
                ></div>
              </div>

              <p className="text-gray-600">
                Your resume matches <strong>{analysisResult.matchScore}%</strong> of the requirements for{' '}
                <strong>{jobRole}</strong> at <strong>{companyName}</strong>
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center space-x-2 mb-4">
                  <CheckCircle2 className="h-6 w-6 text-green-600" />
                  <h3 className="text-lg font-bold text-gray-900">Matched Skills</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {analysisResult.matchedSkills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-3 py-1.5 bg-green-100 text-green-800 rounded-lg text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center space-x-2 mb-4">
                  <XCircle className="h-6 w-6 text-red-600" />
                  <h3 className="text-lg font-bold text-gray-900">Missing Skills</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {analysisResult.missingSkills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-3 py-1.5 bg-red-100 text-red-800 rounded-lg text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 lg:p-8">
              <div className="flex items-center space-x-2 mb-4">
                <Lightbulb className="h-6 w-6 text-yellow-600" />
                <h3 className="text-lg font-bold text-gray-900">Improvement Suggestions</h3>
              </div>
              <div className="prose prose-sm max-w-none">
                <p className="text-gray-700 whitespace-pre-line leading-relaxed">
                  {analysisResult.improvementSuggestions}
                </p>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Keyword Analysis</h3>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Keyword Match Rate</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {analysisResult.keywordAnalysis.matchedKeywords} / {analysisResult.keywordAnalysis.totalKeywords}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-600 mb-1">Match Percentage</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {Math.round((analysisResult.keywordAnalysis.matchedKeywords / analysisResult.keywordAnalysis.totalKeywords) * 100)}%
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
