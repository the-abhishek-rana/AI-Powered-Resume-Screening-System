import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FileText, TrendingUp, User, PlusCircle, Calendar, Trash2, Download } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/firebase';
import { collection, query, where, getDocs, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { generatePDF } from '../lib/pdfUtils';
import { Chatbot } from '../components/Chatbot';

export const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [resumes, setResumes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchResumes = async () => {
      if (!user) return;

      try {
        const q = query(
          collection(db, 'resumes'),
          where('userId', '==', user.uid)
        );
        const querySnapshot = await getDocs(q);
        const resumeList = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        } as any)).sort((a, b) => (b as any).createdAt.seconds - (a as any).createdAt.seconds);
        setResumes(resumeList);
      } catch (error) {
        console.error('Error fetching resumes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchResumes();
  }, [user]);

  const stats = [
    { name: 'Resumes Created', value: resumes.length.toString(), icon: FileText, color: 'bg-blue-500' },
    { name: 'Analyses Run', value: '0', icon: TrendingUp, color: 'bg-green-500' },
    { name: 'Avg Match Score', value: '-', icon: User, color: 'bg-orange-500' },
  ];

  const handleRemoveResume = async (resumeId: string) => {
    const confirmDelete = window.confirm('Are you sure you want to remove this resume? This action cannot be undone.');
    if (!confirmDelete) return;

    try {
      await deleteDoc(doc(db, 'resumes', resumeId));
      setResumes((prevResumes) => prevResumes.filter((resume) => resume.id !== resumeId));
      alert('Resume removed successfully.');
    } catch (error) {
      console.error('Error removing resume:', error);
      alert('Failed to remove resume. Please try again.');
    }
  };

  const handleDownload = (resume: any) => {
    try {
      generatePDF(resume);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to download resume. Please try again.');
    }
  };

  return (
    <div className="p-4 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome back!</h2>
          <p className="text-gray-600">Here's an overview of your resume optimization journey</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat) => (
            <div key={stat.name} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{stat.name}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-xl`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg p-8 text-white">
            <h3 className="text-2xl font-bold mb-3">Create Your Resume</h3>
            <p className="text-blue-100 mb-6">
              Build a professional resume with our intuitive form-based interface
            </p>
            <Link
              to="/dashboard/create-resume"
              className="inline-flex items-center space-x-2 bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              <PlusCircle className="h-5 w-5" />
              <span>Start Building</span>
            </Link>
          </div>

          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg p-8 text-white">
            <h3 className="text-2xl font-bold mb-3">Analyze Your Resume</h3>
            <p className="text-green-100 mb-6">
              Get AI-powered insights on how well your resume matches job requirements
            </p>
            <Link
              to="/dashboard/ranking"
              className="inline-flex items-center space-x-2 bg-white text-green-600 px-6 py-3 rounded-lg font-semibold hover:bg-green-50 transition-colors"
            >
              <TrendingUp className="h-5 w-5" />
              <span>Analyze Now</span>
            </Link>
          </div>
        </div>

        <div className="mt-8 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Saved Resumes</h3>
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
              <p className="text-gray-500">Loading resumes...</p>
            </div>
          ) : resumes.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No resumes saved yet. Start by creating one!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {resumes.map((resume) => (
                <div key={resume.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <FileText className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{resume.resumeTitle}</h4>
                      <p className="text-sm text-gray-600">{resume.fullName}</p>
                      <div className="flex items-center space-x-2 text-xs text-gray-500 mt-1">
                        <Calendar className="h-3 w-3" />
                        <span>{new Date(resume.createdAt.seconds * 1000).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleDownload(resume)}
                      className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center space-x-1"
                      aria-label="Download Resume"
                    >
                      <Download className="h-4 w-4" />
                      <span>Download</span>
                    </button>
                    <Link
                      to={`/dashboard/ranking`}
                      className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
                    >
                      Analyze
                    </Link>
                    <button
                      onClick={() => handleRemoveResume(resume.id)}
                      className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 transition-colors flex items-center space-x-1"
                      aria-label="Remove Resume"
                    >
                      <Trash2 className="h-4 w-4" />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      <Chatbot />
    </div>
  );
};
