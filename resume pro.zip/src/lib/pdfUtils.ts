import * as pdfjsLib from 'pdfjs-dist';
import jsPDF from 'jspdf';

// Set the worker source
pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.js';

export const extractTextFromPDF = async (file: File): Promise<string> => {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;

  let text = '';
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map((item: any) => item.str).join(' ') + '\n';
  }

  return text;
};

interface ResumeData {
  fullName: string;
  email: string;
  phone?: string;
  location?: string;
  linkedin?: string;
  portfolio?: string;
  github?: string;
  summary?: string;
  skills?: {
    languages?: string;
    webTechnologies?: string;
    databases?: string;
    toolsPlatforms?: string;
    otherSkills?: string;
  };
  experiences: Array<{
    company: string;
    position: string;
    startDate: string;
    endDate: string;
    description: string;
  }>;
  educations: Array<{
    institution: string;
    degree: string;
    fieldOfStudy: string;
    graduationYear: string;
    cgpa?: string;
    relevantCoursework?: string;
  }>;
  projects: Array<{
    name: string;
    description: string;
    technologies: string;
    link?: string;
    startDate?: string;
    endDate?: string;
  }>;
  certifications?: Array<{
    name: string;
    organization: string;
  }>;
  achievements?: Array<string>;
  languages?: Array<{
    language: string;
    proficiency: string;
  }>;
  hobbies?: Array<string>;
}

export const generatePDF = (resume: ResumeData): void => {
  const doc = new jsPDF();
  let yPosition = 20;

  // Title - Full Name
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text(resume.fullName, 20, yPosition);
  yPosition += 10;

  // Contact Info - email, phone, location, linkedin, portfolio, github
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const contactInfo = [
    resume.email,
    resume.phone,
    resume.location,
    resume.linkedin ? `LinkedIn: ${resume.linkedin}` : '',
    resume.portfolio ? `Portfolio: ${resume.portfolio}` : '',
    resume.github ? `GitHub: ${resume.github}` : '',
  ].filter(Boolean).join(' | ');
  doc.text(contactInfo, 20, yPosition);
  yPosition += 15;

  // Section helper function
  const addSectionTitle = (title: string) => {
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text(title, 20, yPosition);
    yPosition += 8;
  };

  const addTextBlock = (text: string, fontSize = 12, fontStyle: 'normal' | 'italic' | 'bold' = 'normal') => {
    doc.setFontSize(fontSize);
    doc.setFont('helvetica', fontStyle);
    const lines = doc.splitTextToSize(text, 170);
    doc.text(lines, 20, yPosition);
    yPosition += lines.length * 6;
  };

  // Professional Summary
  if (resume.summary) {
    addSectionTitle('Professional Summary');
    addTextBlock(resume.summary);
    yPosition += 8;
  }

  // Skills - categorized
  if (resume.skills) {
    addSectionTitle('Technical Skills');
    if (resume.skills.languages) {
      addTextBlock(`Languages: ${resume.skills.languages}`);
    }
    if (resume.skills.webTechnologies) {
      addTextBlock(`Web Technologies: ${resume.skills.webTechnologies}`);
    }
    if (resume.skills.databases) {
      addTextBlock(`Databases: ${resume.skills.databases}`);
    }
    if (resume.skills.toolsPlatforms) {
      addTextBlock(`Tools & Platforms: ${resume.skills.toolsPlatforms}`);
    }
    if (resume.skills.otherSkills) {
      addTextBlock(`Other Skills: ${resume.skills.otherSkills}`);
    }
    yPosition += 8;
  }

  // Work Experience
  if (resume.experiences.length > 0) {
    addSectionTitle('Work Experience');
    resume.experiences.forEach(exp => {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.text(`${exp.position} at ${exp.company}`, 20, yPosition);
      yPosition += 6;
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(10);
      doc.text(`${exp.startDate} - ${exp.endDate}`, 20, yPosition);
      yPosition += 6;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(11);
      const descLines = doc.splitTextToSize(exp.description, 170);
      doc.text(descLines, 20, yPosition);
      yPosition += descLines.length * 6 + 6;
    });
    yPosition += 4;
  }

  // Education
  if (resume.educations.length > 0) {
    addSectionTitle('Education');
    resume.educations.forEach(edu => {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.text(`${edu.degree} in ${edu.fieldOfStudy}`, 20, yPosition);
      yPosition += 6;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(11);
      let eduLine = `${edu.institution}, ${edu.graduationYear}`;
      if (edu.cgpa) {
        eduLine += ` | CGPA: ${edu.cgpa}`;
      }
      doc.text(eduLine, 20, yPosition);
      yPosition += 6;
      if (edu.relevantCoursework) {
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(10);
        doc.text(`Relevant Coursework: ${edu.relevantCoursework}`, 20, yPosition);
        yPosition += 6;
      }
      yPosition += 4;
    });
  }

  // Projects
  if (resume.projects.length > 0) {
    addSectionTitle('Projects');
    resume.projects.forEach(proj => {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.text(proj.name, 20, yPosition);
      yPosition += 6;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(11);
      const descLines = doc.splitTextToSize(proj.description, 170);
      doc.text(descLines, 20, yPosition);
      yPosition += descLines.length * 6 + 4;
      if (proj.technologies) {
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(10);
        doc.text(`Technologies: ${proj.technologies}`, 20, yPosition);
        yPosition += 6;
      }
      if (proj.link) {
        doc.text(`Link: ${proj.link}`, 20, yPosition);
        yPosition += 8;
      } else {
        yPosition += 4;
      }
    });
  }

  // Certifications
  if (resume.certifications && resume.certifications.length > 0) {
    addSectionTitle('Certifications');
    resume.certifications.forEach(cert => {
      addTextBlock(`${cert.name} — ${cert.organization}`, 11, 'normal');
      yPosition += 4;
    });
  }

  // Achievements & Awards
  if (resume.achievements && resume.achievements.length > 0) {
    addSectionTitle('Achievements & Awards');
    resume.achievements.forEach(ach => {
      addTextBlock(`- ${ach}`, 11, 'normal');
      yPosition += 4;
    });
  }

  // Languages
  if (resume.languages && resume.languages.length > 0) {
    addSectionTitle('Languages');
    resume.languages.forEach(lang => {
      addTextBlock(`${lang.language} — ${lang.proficiency}`, 11, 'normal');
      yPosition += 4;
    });
  }

  // Hobbies / Interests
  if (resume.hobbies && resume.hobbies.length > 0) {
    addSectionTitle('Hobbies / Interests');
    addTextBlock(resume.hobbies.join(', '), 11, 'normal');
    yPosition += 8;
  }

  // Save PDF
  doc.save(`${resume.fullName.replace(/\s+/g, '_')}_Resume.pdf`);
};
