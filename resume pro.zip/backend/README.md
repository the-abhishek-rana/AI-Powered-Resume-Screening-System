# Resume Analysis Backend

A Flask-based backend service for AI-powered resume analysis using Groq API.

## Features

- PDF resume upload and text extraction
- AI-powered resume analysis against job requirements
- RESTful API endpoints
- CORS enabled for frontend integration
- Comprehensive error handling

## Setup

1. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure environment variables:**
   - Copy `.env` file and update the values:
   ```bash
   GROQ_API_KEY=your_actual_groq_api_key
   FLASK_ENV=development
   FLASK_DEBUG=True
   ```

3. **Run the application:**
   ```bash
   python app.py
   ```

   The server will start on `http://localhost:5000`

## API Endpoints

### POST /analyze-resume
Analyzes a resume against job requirements.

**Request (multipart/form-data):**
- `resume` (file): PDF resume file
- `company_name` (string): Company name
- `job_role` (string): Job role/title
- `job_description` (string, optional): Job description for more accurate analysis

**Response:**
```json
{
  "matchScore": 85,
  "matchedSkills": ["Python", "JavaScript", "React"],
  "missingSkills": ["Docker", "AWS"],
  "improvementSuggestions": "Consider adding Docker and AWS experience...",
  "keywordAnalysis": {
    "totalKeywords": 20,
    "matchedKeywords": 15
  }
}
```

### GET /health
Health check endpoint.

**Response:**
```json
{
  "status": "healthy"
}
```

## Error Responses

The API returns appropriate HTTP status codes and error messages:

- `400 Bad Request`: Missing required fields or invalid file type
- `500 Internal Server Error`: Server-side errors

Error response format:
```json
{
  "error": "Error description"
}
```

## Integration with Frontend

To integrate with your React frontend:

1. Update your frontend to send requests to `http://localhost:5000/analyze-resume`
2. Change the request format from direct Groq API calls to the backend endpoint
3. Handle the same response format as before

Example frontend integration:
```javascript
const formData = new FormData();
formData.append('resume', pdfFile);
formData.append('company_name', companyName);
formData.append('job_role', jobRole);
formData.append('job_description', jobDescription);

const response = await fetch('http://localhost:5000/analyze-resume', {
  method: 'POST',
  body: formData
});

const analysisResult = await response.json();
