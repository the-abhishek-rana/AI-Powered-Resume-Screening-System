from flask import Flask, request, jsonify
from flask_cors import CORS
from groq import Groq
import os
from dotenv import load_dotenv
from utils import extract_text_from_pdf
import json

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "http://localhost:5173"}}, supports_credentials=True, allow_headers="*", methods=["GET", "POST", "OPTIONS"])  # Enable CORS for frontend origin

# Initialize Groq client
groq_client = Groq(api_key=os.getenv('GROQ_API_KEY'))

@app.route('/analyze-resume', methods=['POST'])
def analyze_resume():
    """
    Analyze a resume against job requirements using AI.

    Expected form data:
    - resume: PDF file
    - company_name: string
    - job_role: string
    - job_description: string (optional)
    """
    try:
        # Validate required fields
        if 'resume' not in request.files:
            return jsonify({'error': 'No resume file provided'}), 400

        resume_file = request.files['resume']
        company_name = request.form.get('company_name')
        job_role = request.form.get('job_role')
        job_description = request.form.get('job_description', '')

        if not company_name or not job_role:
            return jsonify({'error': 'Company name and job role are required'}), 400

        # Validate file type
        if not resume_file.filename.lower().endswith('.pdf'):
            return jsonify({'error': 'Only PDF files are allowed'}), 400

        # Extract text from PDF
        resume_text = extract_text_from_pdf(resume_file)

        if not resume_text.strip():
            return jsonify({'error': 'Could not extract text from the PDF'}), 400

        # Create the analysis prompt
        prompt = f"""
        Analyze this resume for the job role "{job_role}" at "{company_name}".
        {f'Job description: {job_description}' if job_description else ''}
        Resume text: {resume_text}

        Respond ONLY with a valid JSON object in the following exact structure. Do not include any explanations, markdown, or additional text:

        {{
          "matchScore": number (0-100),
          "matchedSkills": array of strings,
          "missingSkills": array of strings,
          "improvementSuggestions": string,
          "keywordAnalysis": {{
            "totalKeywords": number,
            "matchedKeywords": number
          }}
        }}
        """

        # Call Groq API
        response = groq_client.chat.completions.create(
            messages=[{"role": "user", "content": prompt}],
            model="llama-3.1-8b-instant",
            temperature=0,
        )

        if not response.choices or not response.choices[0].message.content:
            return jsonify({'error': 'Failed to get analysis from AI service'}), 500

        # Parse the JSON response
        try:
            analysis_result = json.loads(response.choices[0].message.content)
            return jsonify(analysis_result)
        except json.JSONDecodeError:
            return jsonify({'error': 'Invalid response format from AI service'}), 500

    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        app.logger.error(f"Unexpected error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/chatbot', methods=['POST'])
def chatbot():
    """
    Chatbot endpoint for answering user questions about the app.

    Expected JSON data:
    - messages: array of message objects with 'role' and 'content'
    """
    try:
        data = request.get_json()
        if not data or 'messages' not in data:
            return jsonify({'error': 'Messages are required'}), 400

        messages = data['messages']
        if not isinstance(messages, list) or len(messages) == 0:
            return jsonify({'error': 'Messages must be a non-empty array'}), 400

        # Create a system prompt for the chatbot
        system_prompt = """
        You are a helpful assistant for a resume optimization app. The app allows users to:
        - Create professional resumes using a form-based interface
        - Analyze resumes against job requirements using AI
        - Get insights on match scores, matched/missing skills, and improvement suggestions

        Answer user questions about how to use the app, resume best practices, job search tips, and general career advice.
        Be friendly, concise, and helpful. If asked about technical details, explain them simply.
        """

        # Add system message to the conversation
        conversation = [{"role": "system", "content": system_prompt}] + messages

        # Call Groq API for chatbot response
        response = groq_client.chat.completions.create(
            messages=conversation,
            model="llama-3.1-8b-instant",
            temperature=0.7,
            max_tokens=500,
        )

        if not response.choices or not response.choices[0].message.content:
            return jsonify({'error': 'Failed to get response from AI service'}), 500

        reply = response.choices[0].message.content.strip()
        return jsonify({'reply': reply})

    except Exception as e:
        app.logger.error(f"Chatbot error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy'})

if __name__ == '__main__':
    app.run(
        debug=os.getenv('FLASK_DEBUG', 'False').lower() == 'true',
        host='0.0.0.0',
        port=int(os.getenv('PORT', 5000))
    )
